"""
聊天模块测试
测试聊天室和消息功能
"""
import pytest
from fastapi.testclient import TestClient


class TestRoomCreation:
    """聊天室创建测试"""

    def test_create_room_success(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试成功创建聊天室"""
        response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == test_room_data["name"]
        assert data["description"] == test_room_data["description"]
        assert "id" in data
        assert "creator_id" in data

    def test_create_room_without_auth(self, client: TestClient, test_room_data: dict):
        """测试未认证创建聊天室"""
        response = client.post("/api/rooms", json=test_room_data)
        
        assert response.status_code == 403

    def test_create_room_with_members(self, client: TestClient, auth_header: dict, test_user_data2: dict):
        """测试创建聊天室并添加成员"""
        # 先注册第二个用户
        client.post("/api/auth/register", json=test_user_data2)
        
        # 创建聊天室并添加成员
        response = client.post(
            "/api/rooms",
            json={
                "name": "测试聊天室",
                "description": "测试",
                "member_ids": [2]  # 第二个用户的ID
            },
            headers=auth_header
        )
        
        assert response.status_code == 201
        data = response.json()
        assert data["member_count"] >= 1


class TestRoomQuery:
    """聊天室查询测试"""

    def test_get_rooms_list(self, client: TestClient, auth_header: dict):
        """测试获取聊天室列表"""
        response = client.get("/api/rooms", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)

    def test_get_my_rooms(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试获取我的聊天室"""
        # 先创建一个聊天室
        client.post("/api/rooms", json=test_room_data, headers=auth_header)
        
        response = client.get("/api/rooms/my", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_get_room_by_id(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试获取聊天室详情"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 获取聊天室详情
        response = client.get(f"/api/rooms/{room_id}", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == room_id
        assert data["name"] == test_room_data["name"]

    def test_get_nonexistent_room(self, client: TestClient, auth_header: dict):
        """测试获取不存在的聊天室"""
        response = client.get("/api/rooms/99999", headers=auth_header)
        
        assert response.status_code == 404


class TestRoomManagement:
    """聊天室管理测试"""

    def test_update_room(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试更新聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 更新聊天室
        response = client.put(
            f"/api/rooms/{room_id}",
            json={"name": "更新后的名称", "description": "更新后的描述"},
            headers=auth_header
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "更新后的名称"

    def test_delete_room(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试删除聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 删除聊天室
        response = client.delete(f"/api/rooms/{room_id}", headers=auth_header)
        
        assert response.status_code == 200
        
        # 验证已删除
        get_response = client.get(f"/api/rooms/{room_id}", headers=auth_header)
        assert get_response.status_code == 404

    def test_join_room(self, client: TestClient, auth_header: dict, test_room_data: dict, test_user_data2: dict):
        """测试加入聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 注册第二个用户
        client.post("/api/auth/register", json=test_user_data2)
        
        # 登录获取token
        login_response = client.post(
            "/api/auth/login",
            json={"username": test_user_data2["username"], "password": test_user_data2["password"]}
        )
        token2 = login_response.json()["access_token"]
        auth_header2 = {"Authorization": f"Bearer {token2}"}
        
        # 加入聊天室
        response = client.post(f"/api/rooms/{room_id}/join", headers=auth_header2)
        
        assert response.status_code == 200


class TestMessageAPI:
    """消息API测试"""

    def test_send_message(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试发送消息"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 发送消息
        response = client.post(
            "/api/messages",
            json={"room_id": room_id, "content": "测试消息"},
            headers=auth_header
        )
        
        assert response.status_code == 201
        data = response.json()
        assert data["content"] == "测试消息"
        assert data["room_id"] == room_id

    def test_send_message_to_nonexistent_room(self, client: TestClient, auth_header: dict):
        """测试向不存在的聊天室发送消息"""
        response = client.post(
            "/api/messages",
            json={"room_id": 99999, "content": "测试消息"},
            headers=auth_header
        )
        
        assert response.status_code == 403  # 不是成员

    def test_get_room_messages(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试获取聊天室消息"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 发送消息
        client.post(
            "/api/messages",
            json={"room_id": room_id, "content": "消息1"},
            headers=auth_header
        )
        client.post(
            "/api/messages",
            json={"room_id": room_id, "content": "消息2"},
            headers=auth_header
        )
        
        # 获取消息
        response = client.get(f"/api/rooms/{room_id}/messages", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 2

    def test_delete_message(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试删除消息"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 发送消息
        send_response = client.post(
            "/api/messages",
            json={"room_id": room_id, "content": "要删除的消息"},
            headers=auth_header
        )
        message_id = send_response.json()["id"]
        
        # 删除消息
        response = client.delete(f"/api/messages/{message_id}", headers=auth_header)
        
        assert response.status_code == 200


class TestRoomMembers:
    """聊天室成员测试"""

    def test_add_member(self, client: TestClient, auth_header: dict, test_room_data: dict, test_user_data2: dict):
        """测试添加成员"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 注册第二个用户
        register_response = client.post("/api/auth/register", json=test_user_data2)
        user_id = register_response.json()["id"]
        
        # 添加成员
        response = client.post(
            f"/api/rooms/{room_id}/members",
            json={"user_id": user_id},
            headers=auth_header
        )
        
        assert response.status_code == 200

    def test_remove_member(self, client: TestClient, auth_header: dict, test_room_data: dict, test_user_data2: dict):
        """测试移除成员"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 注册第二个用户并加入
        register_response = client.post("/api/auth/register", json=test_user_data2)
        user_id = register_response.json()["id"]
        
        client.post(
            f"/api/rooms/{room_id}/members",
            json={"user_id": user_id},
            headers=auth_header
        )
        
        # 移除成员
        response = client.delete(f"/api/rooms/{room_id}/members/{user_id}", headers=auth_header)
        
        assert response.status_code == 200
