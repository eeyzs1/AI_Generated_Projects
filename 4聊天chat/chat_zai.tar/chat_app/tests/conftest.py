"""
测试配置文件
提供测试夹具和共享配置
"""
import os
import sys
import pytest
from typing import Generator
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 在导入数据库模块之前设置测试数据库URL
os.environ["DATABASE_URL"] = "sqlite:///./test_chat_app.db"

from database import Base, get_db
from main import app


# 测试数据库配置（使用内存SQLite）
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)

TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    """
    覆盖数据库依赖，使用测试数据库
    """
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


# 覆盖应用中的数据库依赖
app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="function")
def db() -> Generator:
    """
    创建测试数据库会话
    每个测试函数都会创建新的数据库
    """
    # 创建所有表
    Base.metadata.create_all(bind=engine)
    
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        # 测试结束后删除所有表
        Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(db) -> TestClient:
    """
    创建测试客户端
    """
    return TestClient(app)


@pytest.fixture
def test_user_data():
    """
    测试用户数据
    """
    return {
        "username": "testuser",
        "email": "test@example.com",
        "password": "Test123456"
    }


@pytest.fixture
def test_user_data2():
    """
    第二个测试用户数据
    """
    return {
        "username": "testuser2",
        "email": "test2@example.com",
        "password": "Test123456"
    }


@pytest.fixture
def registered_user(client: TestClient, test_user_data: dict):
    """
    注册并返回用户数据
    """
    response = client.post("/api/auth/register", json=test_user_data)
    assert response.status_code == 201
    return response.json()


@pytest.fixture
def auth_header(client: TestClient, test_user_data: dict, registered_user: dict):
    """
    获取认证头
    """
    # 登录获取token
    response = client.post(
        "/api/auth/login",
        json={
            "username": test_user_data["username"],
            "password": test_user_data["password"]
        }
    )
    assert response.status_code == 200
    token = response.json()["access_token"]
    
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def test_room_data():
    """
    测试聊天室数据
    """
    return {
        "name": "测试聊天室",
        "description": "这是一个测试聊天室"
    }
