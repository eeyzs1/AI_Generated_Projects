"""
认证模块测试
测试用户注册、登录、Token验证等功能
"""
import pytest
from fastapi.testclient import TestClient


class TestUserRegistration:
    """用户注册测试"""

    def test_register_success(self, client: TestClient, test_user_data: dict):
        """测试成功注册"""
        response = client.post("/api/auth/register", json=test_user_data)
        
        assert response.status_code == 201
        data = response.json()
        assert data["username"] == test_user_data["username"]
        assert data["email"] == test_user_data["email"]
        assert "id" in data
        assert "hashed_password" not in data  # 不应返回密码

    def test_register_duplicate_username(self, client: TestClient, test_user_data: dict):
        """测试重复用户名注册"""
        # 第一次注册
        client.post("/api/auth/register", json=test_user_data)
        
        # 尝试用相同用户名注册
        response = client.post("/api/auth/register", json=test_user_data)
        
        assert response.status_code == 400
        assert "用户名已被注册" in response.json()["detail"]

    def test_register_duplicate_email(self, client: TestClient, test_user_data: dict):
        """测试重复邮箱注册"""
        # 第一次注册
        client.post("/api/auth/register", json=test_user_data)
        
        # 尝试用相同邮箱注册（不同用户名）
        new_user = test_user_data.copy()
        new_user["username"] = "different_user"
        response = client.post("/api/auth/register", json=new_user)
        
        assert response.status_code == 400
        assert "邮箱已被注册" in response.json()["detail"]

    def test_register_short_username(self, client: TestClient):
        """测试用户名过短"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "ab",  # 少于3个字符
                "email": "test@example.com",
                "password": "Test123456"
            }
        )
        assert response.status_code == 422  # 验证错误

    def test_register_weak_password(self, client: TestClient):
        """测试弱密码（无数字）"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "testuser",
                "email": "test@example.com",
                "password": "weakpassword"  # 无数字
            }
        )
        assert response.status_code == 422

    def test_register_invalid_email(self, client: TestClient):
        """测试无效邮箱格式"""
        response = client.post(
            "/api/auth/register",
            json={
                "username": "testuser",
                "email": "invalid-email",
                "password": "Test123456"
            }
        )
        assert response.status_code == 422


class TestUserLogin:
    """用户登录测试"""

    def test_login_success(self, client: TestClient, test_user_data: dict, registered_user: dict):
        """测试成功登录"""
        response = client.post(
            "/api/auth/login",
            json={
                "username": test_user_data["username"],
                "password": test_user_data["password"]
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        assert "user" in data
        assert data["user"]["username"] == test_user_data["username"]

    def test_login_wrong_password(self, client: TestClient, test_user_data: dict, registered_user: dict):
        """测试错误密码登录"""
        response = client.post(
            "/api/auth/login",
            json={
                "username": test_user_data["username"],
                "password": "WrongPassword123"
            }
        )
        
        assert response.status_code == 401
        assert "用户名或密码错误" in response.json()["detail"]

    def test_login_nonexistent_user(self, client: TestClient):
        """测试不存在的用户登录"""
        response = client.post(
            "/api/auth/login",
            json={
                "username": "nonexistent",
                "password": "SomePassword123"
            }
        )
        
        assert response.status_code == 401
        assert "用户名或密码错误" in response.json()["detail"]


class TestTokenValidation:
    """Token验证测试"""

    def test_get_current_user_success(self, client: TestClient, auth_header: dict, test_user_data: dict):
        """测试获取当前用户"""
        response = client.get("/api/auth/me", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == test_user_data["username"]
        assert data["email"] == test_user_data["email"]

    def test_get_current_user_invalid_token(self, client: TestClient):
        """测试无效Token"""
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": "Bearer invalid_token"}
        )
        
        assert response.status_code == 401

    def test_get_current_user_no_token(self, client: TestClient):
        """测试无Token"""
        response = client.get("/api/auth/me")
        
        assert response.status_code == 403  # 未提供认证信息

    def test_get_current_user_expired_token(self, client: TestClient):
        """测试过期Token（模拟）"""
        # 使用一个明显无效的token
        expired_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        response = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {expired_token}"}
        )
        
        assert response.status_code == 401


class TestUserLogout:
    """用户登出测试"""

    def test_logout_success(self, client: TestClient, auth_header: dict):
        """测试成功登出"""
        response = client.post("/api/auth/logout", headers=auth_header)
        
        assert response.status_code == 200
        assert "登出成功" in response.json()["message"]

    def test_logout_without_auth(self, client: TestClient):
        """测试未认证登出"""
        response = client.post("/api/auth/logout")
        
        assert response.status_code == 403


class TestUserAPI:
    """用户API测试"""

    def test_get_users_list(self, client: TestClient, auth_header: dict, registered_user: dict):
        """测试获取用户列表"""
        response = client.get("/api/users", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_get_online_users(self, client: TestClient, auth_header: dict):
        """测试获取在线用户"""
        response = client.get("/api/users/online", headers=auth_header)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
