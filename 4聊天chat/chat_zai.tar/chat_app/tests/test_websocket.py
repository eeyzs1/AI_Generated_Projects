"""
WebSocket测试
测试实时消息传递功能
"""
import pytest
import json
from fastapi.testclient import TestClient


class TestWebSocket:
    """WebSocket功能测试"""

    def test_websocket_connect_with_valid_token(self, client: TestClient, auth_header: dict):
        """测试使用有效Token连接WebSocket"""
        # 获取token
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 连接成功，可以发送消息
            websocket.send_json({"type": "online_users"})
            # 等待响应
            response = websocket.receive_json()
            assert response["type"] == "online_users"

    def test_websocket_connect_without_token(self, client: TestClient):
        """测试不带Token连接WebSocket"""
        with pytest.raises(Exception):
            with client.websocket_connect("/ws"):
                pass

    def test_websocket_connect_with_invalid_token(self, client: TestClient):
        """测试使用无效Token连接WebSocket"""
        with pytest.raises(Exception):
            with client.websocket_connect("/ws?token=invalid_token"):
                pass

    def test_websocket_join_room(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试通过WebSocket加入聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 发送加入聊天室消息
            websocket.send_json({
                "type": "join",
                "room_id": room_id
            })
            # 应该收到系统消息
            response = websocket.receive_json()
            assert response["type"] == "system"

    def test_websocket_send_message(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试通过WebSocket发送消息"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 先加入聊天室
            websocket.send_json({
                "type": "join",
                "room_id": room_id
            })
            websocket.receive_json()  # 接收系统消息
            
            # 发送消息
            websocket.send_json({
                "type": "message",
                "room_id": room_id,
                "content": "Hello, WebSocket!"
            })
            # 接收自己发送的消息
            response = websocket.receive_json()
            assert response["type"] == "message"
            assert response["content"] == "Hello, WebSocket!"

    def test_websocket_typing_indicator(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试正在输入状态"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 加入聊天室
            websocket.send_json({
                "type": "join",
                "room_id": room_id
            })
            websocket.receive_json()
            
            # 发送正在输入状态
            websocket.send_json({
                "type": "typing",
                "room_id": room_id
            })
            # 应该收到typing消息
            response = websocket.receive_json()
            assert response["type"] == "typing"

    def test_websocket_leave_room(self, client: TestClient, auth_header: dict, test_room_data: dict):
        """测试离开聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 加入聊天室
            websocket.send_json({
                "type": "join",
                "room_id": room_id
            })
            websocket.receive_json()
            
            # 离开聊天室
            websocket.send_json({
                "type": "leave",
                "room_id": room_id
            })
            # 应该收到系统消息
            response = websocket.receive_json()
            assert response["type"] == "system"
            assert "离开" in response["content"]


class TestWebSocketMultipleUsers:
    """多用户WebSocket测试"""

    def test_multiple_users_same_room(
        self, 
        client: TestClient, 
        auth_header: dict, 
        test_user_data2: dict,
        test_room_data: dict
    ):
        """测试多用户在同一聊天室"""
        # 创建聊天室
        create_response = client.post("/api/rooms", json=test_room_data, headers=auth_header)
        room_id = create_response.json()["id"]
        
        # 第一个用户的token
        token1 = auth_header["Authorization"].replace("Bearer ", "")
        
        # 注册并登录第二个用户
        client.post("/api/auth/register", json=test_user_data2)
        login_response = client.post(
            "/api/auth/login",
            json={"username": test_user_data2["username"], "password": test_user_data2["password"]}
        )
        token2 = login_response.json()["access_token"]
        
        # 两个用户同时连接WebSocket
        with client.websocket_connect(f"/ws?token={token1}") as ws1, \
             client.websocket_connect(f"/ws?token={token2}") as ws2:
            
            # 两个用户都加入聊天室
            ws1.send_json({"type": "join", "room_id": room_id})
            ws1.receive_json()
            
            ws2.send_json({"type": "join", "room_id": room_id})
            # 用户2会收到用户1的加入通知
            ws1.receive_json()  # 用户1收到用户2加入的通知
            ws2.receive_json()  # 用户2收到自己的加入通知
            
            # 用户1发送消息
            ws1.send_json({
                "type": "message",
                "room_id": room_id,
                "content": "来自用户1的消息"
            })
            
            # 两个用户都应该收到消息
            msg1 = ws1.receive_json()
            assert msg1["content"] == "来自用户1的消息"
            
            msg2 = ws2.receive_json()
            assert msg2["content"] == "来自用户1的消息"


class TestWebSocketOnlineUsers:
    """在线用户测试"""

    def test_get_online_users_via_websocket(self, client: TestClient, auth_header: dict):
        """测试通过WebSocket获取在线用户"""
        token = auth_header["Authorization"].replace("Bearer ", "")
        
        with client.websocket_connect(f"/ws?token={token}") as websocket:
            # 请求在线用户列表
            websocket.send_json({"type": "online_users"})
            
            response = websocket.receive_json()
            assert response["type"] == "online_users"
            assert "users" in response
            assert isinstance(response["users"], list)
