import React, { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom'
import Login from './Login'
import Register from './Register'
import ChatRoom from './ChatRoom'
import UserList from './UserList'
import { useAppStore } from './store'
import { authApi, roomApi } from './api'
import { Room } from './store'

// 主聊天界面组件
const ChatMain: React.FC = () => {
  const navigate = useNavigate()
  const user = useAppStore((state) => state.user)
  const rooms = useAppStore((state) => state.rooms)
  const setRooms = useAppStore((state) => state.setRooms)
  const logout = useAppStore((state) => state.logout)

  const [showCreateRoom, setShowCreateRoom] = useState(false)
  const [newRoomName, setNewRoomName] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRooms()
  }, [])

  const fetchRooms = async () => {
    try {
      const response = await roomApi.getMyRooms()
      setRooms(response.data)
    } catch (error) {
      console.error('获取聊天室列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newRoomName.trim()) return

    try {
      const response = await roomApi.createRoom({ name: newRoomName.trim() })
      setRooms([...rooms, response.data])
      setShowCreateRoom(false)
      setNewRoomName('')
    } catch (error) {
      console.error('创建聊天室失败:', error)
    }
  }

  const handleLogout = async () => {
    try {
      await authApi.logout()
    } catch (error) {
      console.error('登出失败:', error)
    }
    logout()
    navigate('/login')
  }

  if (loading) {
    return <div className="loading">加载中...</div>
  }

  return (
    <div className="chat-main">
      {/* 侧边栏 */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="user-info">
            <div className="user-avatar">
              {user?.username?.[0]?.toUpperCase() || '?'}
            </div>
            <span className="username">{user?.username}</span>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            退出
          </button>
        </div>

        <div className="room-list">
          <div className="room-list-header">
            <h3>聊天室</h3>
            <button
              className="create-room-btn"
              onClick={() => setShowCreateRoom(true)}
            >
              +
            </button>
          </div>

          <div className="rooms">
            {rooms.map((room) => (
              <div
                key={room.id}
                className="room-item"
                onClick={() => navigate(`/chat/room/${room.id}`)}
              >
                <div className="room-avatar">
                  {room.name[0].toUpperCase()}
                </div>
                <div className="room-info">
                  <span className="room-name">{room.name}</span>
                  <span className="room-members">
                    {room.member_count} 人
                  </span>
                </div>
              </div>
            ))}

            {rooms.length === 0 && (
              <div className="no-rooms">
                暂无聊天室，点击上方 + 创建
              </div>
            )}
          </div>
        </div>

        {/* 用户列表 */}
        <div className="online-users">
          <UserList />
        </div>
      </div>

      {/* 欢迎区域 */}
      <div className="welcome-area">
        <div className="welcome-content">
          <h2>欢迎使用微信风格聊天应用</h2>
          <p>选择一个聊天室开始聊天，或创建新的聊天室</p>
        </div>
      </div>

      {/* 创建聊天室弹窗 */}
      {showCreateRoom && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>创建聊天室</h3>
              <button onClick={() => setShowCreateRoom(false)}>×</button>
            </div>
            <form onSubmit={handleCreateRoom} className="modal-form">
              <div className="form-group">
                <label>聊天室名称</label>
                <input
                  type="text"
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  placeholder="请输入聊天室名称"
                  required
                  className="input"
                />
              </div>
              <div className="modal-actions">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowCreateRoom(false)}
                >
                  取消
                </button>
                <button type="submit" className="btn btn-primary">
                  创建
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

// 受保护的路由组件
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isAuthenticated = useAppStore((state) => state.isAuthenticated)
  const token = useAppStore((state) => state.token)
  const setUser = useAppStore((state) => state.setUser)
  const setToken = useAppStore((state) => state.setToken)
  const connectWebSocket = useAppStore((state) => state.connectWebSocket)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkAuth = async () => {
      if (token) {
        try {
          const response = await authApi.getMe()
          setUser(response.data)
          connectWebSocket(token)
        } catch (error) {
          setToken(null)
        }
      }
      setLoading(false)
    }

    checkAuth()
  }, [])

  if (loading) {
    return <div className="loading">加载中...</div>
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}

// 主应用组件
const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/chat"
          element={
            <ProtectedRoute>
              <ChatMain />
            </ProtectedRoute>
          }
        />
        <Route
          path="/chat/room/:roomId"
          element={
            <ProtectedRoute>
              <ChatRoom />
            </ProtectedRoute>
          }
        />
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
