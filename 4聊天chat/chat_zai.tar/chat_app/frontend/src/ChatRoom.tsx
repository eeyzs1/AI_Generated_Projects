import React, { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { roomApi, messageApi } from './api'
import { useAppStore, Message, User } from './store'

const ChatRoom: React.FC = () => {
  const { roomId } = useParams<{ roomId: string }>()
  const navigate = useNavigate()

  const currentRoom = useAppStore((state) => state.currentRoom)
  const setCurrentRoom = useAppStore((state) => state.setCurrentRoom)
  const messages = useAppStore((state) => state.messages)
  const setMessages = useAppStore((state) => state.setMessages)
  const user = useAppStore((state) => state.user)
  const wsConnected = useAppStore((state) => state.wsConnected)
  const sendWebSocketMessage = useAppStore((state) => state.sendWebSocketMessage)

  const [messageInput, setMessageInput] = useState('')
  const [loading, setLoading] = useState(true)
  const [showMembers, setShowMembers] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (roomId) {
      fetchRoom()
      fetchMessages()
    }

    return () => {
      // 离开聊天室
      if (currentRoom) {
        sendWebSocketMessage({ type: 'leave', room_id: currentRoom.id })
      }
      setCurrentRoom(null)
    }
  }, [roomId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const fetchRoom = async () => {
    try {
      const response = await roomApi.getRoom(parseInt(roomId!))
      setCurrentRoom(response.data)
    } catch (error) {
      console.error('获取聊天室信息失败:', error)
      navigate('/chat')
    } finally {
      setLoading(false)
    }
  }

  const fetchMessages = async () => {
    try {
      const response = await messageApi.getRoomMessages(parseInt(roomId!))
      setMessages(response.data)
    } catch (error) {
      console.error('获取消息失败:', error)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!messageInput.trim() || !currentRoom) return

    // 通过WebSocket发送消息
    sendWebSocketMessage({
      type: 'message',
      room_id: currentRoom.id,
      content: messageInput.trim()
    })

    setMessageInput('')
  }

  const handleTyping = () => {
    if (currentRoom) {
      sendWebSocketMessage({ type: 'typing', room_id: currentRoom.id })
    }
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return <div className="loading">加载中...</div>
  }

  if (!currentRoom) {
    return <div className="error">聊天室不存在</div>
  }

  return (
    <div className="chat-room">
      {/* 聊天室头部 */}
      <div className="chat-header">
        <button className="back-btn" onClick={() => navigate('/chat')}>
          ← 返回
        </button>
        <div className="chat-info">
          <h3>{currentRoom.name}</h3>
          <span className="member-count">
            {currentRoom.members?.length || 0} 人
          </span>
        </div>
        <button
          className="members-btn"
          onClick={() => setShowMembers(!showMembers)}
        >
          👥
        </button>
      </div>

      {/* 消息区域 */}
      <div className="messages-container">
        <div className="messages-list">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`message-item ${
                msg.sender_id === user?.id ? 'own' : ''
              } ${msg.message_type === 'system' ? 'system' : ''}`}
            >
              {msg.message_type === 'system' ? (
                <div className="system-message">{msg.content}</div>
              ) : (
                <>
                  <div className="message-avatar">
                    {msg.sender_name?.[0]?.toUpperCase() || '?'}
                  </div>
                  <div className="message-content">
                    <div className="message-header">
                      <span className="sender-name">{msg.sender_name}</span>
                      <span className="message-time">
                        {formatTime(msg.created_at)}
                      </span>
                    </div>
                    <div className="message-text">{msg.content}</div>
                  </div>
                </>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* 输入区域 */}
      <div className="message-input-container">
        <form onSubmit={handleSendMessage} className="message-form">
          <input
            type="text"
            value={messageInput}
            onChange={(e) => {
              setMessageInput(e.target.value)
              handleTyping()
            }}
            placeholder="输入消息..."
            className="message-input"
          />
          <button
            type="submit"
            className="send-btn"
            disabled={!messageInput.trim()}
          >
            发送
          </button>
        </form>
        {!wsConnected && (
          <div className="connection-status">连接断开，正在重连...</div>
        )}
      </div>

      {/* 成员列表侧边栏 */}
      {showMembers && (
        <div className="members-sidebar">
          <div className="sidebar-header">
            <h4>聊天室成员</h4>
            <button onClick={() => setShowMembers(false)}>×</button>
          </div>
          <div className="members-list">
            {currentRoom.members?.map((member: User) => (
              <div key={member.id} className="member-item">
                <div className="member-avatar">
                  {member.username[0].toUpperCase()}
                </div>
                <span className="member-name">{member.username}</span>
                {member.is_online && <span className="online-indicator"></span>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default ChatRoom
