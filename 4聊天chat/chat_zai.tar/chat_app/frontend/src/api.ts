import axios from 'axios'
import { useAppStore } from './store'

// 创建axios实例
const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    const token = useAppStore.getState().token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token过期，清除登录状态
      useAppStore.getState().logout()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// 认证API
export const authApi = {
  register: (data: { username: string; email: string; password: string }) =>
    api.post('/auth/register', data),

  login: (data: { username: string; password: string }) =>
    api.post('/auth/login', data),

  logout: () => api.post('/auth/logout'),

  getMe: () => api.get('/auth/me')
}

// 用户API
export const userApi = {
  getUsers: (skip = 0, limit = 100) =>
    api.get(`/users?skip=${skip}&limit=${limit}`),

  getOnlineUsers: () => api.get('/users/online')
}

// 聊天室API
export const roomApi = {
  createRoom: (data: { name: string; description?: string; member_ids?: number[] }) =>
    api.post('/rooms', data),

  getRooms: (skip = 0, limit = 100) =>
    api.get(`/rooms?skip=${skip}&limit=${limit}`),

  getMyRooms: () => api.get('/rooms/my'),

  getRoom: (roomId: number) => api.get(`/rooms/${roomId}`),

  updateRoom: (roomId: number, data: { name?: string; description?: string }) =>
    api.put(`/rooms/${roomId}`, data),

  deleteRoom: (roomId: number) => api.delete(`/rooms/${roomId}`),

  addMember: (roomId: number, userId: number) =>
    api.post(`/rooms/${roomId}/members`, { user_id: userId }),

  removeMember: (roomId: number, memberId: number) =>
    api.delete(`/rooms/${roomId}/members/${memberId}`),

  joinRoom: (roomId: number) => api.post(`/rooms/${roomId}/join`)
}

// 消息API
export const messageApi = {
  sendMessage: (data: { room_id: number; content: string }) =>
    api.post('/messages', data),

  getRoomMessages: (roomId: number, skip = 0, limit = 50) =>
    api.get(`/rooms/${roomId}/messages?skip=${skip}&limit=${limit}`),

  deleteMessage: (messageId: number) => api.delete(`/messages/${messageId}`)
}

export default api
