import React, { useEffect, useState } from 'react'
import { userApi } from './api'
import { useAppStore, User } from './store'

const UserList: React.FC = () => {
  const onlineUsers = useAppStore((state) => state.onlineUsers)
  const setOnlineUsers = useAppStore((state) => state.setOnlineUsers)
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      const response = await userApi.getUsers()
      setAllUsers(response.data)
    } catch (error) {
      console.error('获取用户列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const isOnline = (userId: number) => {
    return onlineUsers.some((u) => u.id === userId)
  }

  if (loading) {
    return <div className="loading">加载中...</div>
  }

  return (
    <div className="user-list">
      <div className="user-list-header">
        <h3>用户列表</h3>
        <span className="online-count">
          {onlineUsers.length} 人在线
        </span>
      </div>

      <div className="user-list-content">
        {/* 在线用户 */}
        <div className="user-section">
          <div className="section-title">在线用户</div>
          {onlineUsers.map((user) => (
            <div key={user.id} className="user-item online">
              <div className="user-avatar">
                {user.avatar ? (
                  <img src={user.avatar} alt={user.username} />
                ) : (
                  <div className="avatar-placeholder">
                    {user.username[0].toUpperCase()}
                  </div>
                )}
                <span className="online-dot"></span>
              </div>
              <div className="user-info">
                <span className="username">{user.username}</span>
              </div>
            </div>
          ))}
        </div>

        {/* 所有用户 */}
        <div className="user-section">
          <div className="section-title">所有用户</div>
          {allUsers.map((user) => (
            <div
              key={user.id}
              className={`user-item ${isOnline(user.id) ? 'online' : ''}`}
            >
              <div className="user-avatar">
                {user.avatar ? (
                  <img src={user.avatar} alt={user.username} />
                ) : (
                  <div className="avatar-placeholder">
                    {user.username[0].toUpperCase()}
                  </div>
                )}
                {isOnline(user.id) && <span className="online-dot"></span>}
              </div>
              <div className="user-info">
                <span className="username">{user.username}</span>
                <span className="user-status">
                  {isOnline(user.id) ? '在线' : '离线'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default UserList
