import { create } from 'zustand'

// 用户类型
export interface User {
  id: number
  username: string
  email: string
  avatar?: string
  is_online: boolean
}

// 聊天室类型
export interface Room {
  id: number
  name: string
  description?: string
  creator_id: number
  member_count: number
  members?: User[]
}

// 消息类型
export interface Message {
  id: number
  sender_id: number
  sender_name: string
  room_id: number
  content: string
  message_type: string
  is_read: boolean
  created_at: string
}

// 应用状态接口
interface AppState {
  // 用户状态
  user: User | null
  token: string | null
  isAuthenticated: boolean

  // 聊天室状态
  rooms: Room[]
  currentRoom: Room | null

  // 消息状态
  messages: Message[]

  // 在线用户
  onlineUsers: User[]

  // WebSocket连接
  ws: WebSocket | null
  wsConnected: boolean

  // 操作方法
  setUser: (user: User | null) => void
  setToken: (token: string | null) => void
  login: (user: User, token: string) => void
  logout: () => void

  setRooms: (rooms: Room[]) => void
  addRoom: (room: Room) => void
  setCurrentRoom: (room: Room | null) => void

  setMessages: (messages: Message[]) => void
  addMessage: (message: Message) => void

  setOnlineUsers: (users: User[]) => void

  connectWebSocket: (token: string) => void
  disconnectWebSocket: () => void
  sendWebSocketMessage: (data: any) => void
}

// 创建store
export const useAppStore = create<AppState>((set, get) => ({
  // 初始状态
  user: null,
  token: localStorage.getItem('token'),
  isAuthenticated: !!localStorage.getItem('token'),

  rooms: [],
  currentRoom: null,

  messages: [],

  onlineUsers: [],

  ws: null,
  wsConnected: false,

  // 用户操作
  setUser: (user) => set({ user }),

  setToken: (token) => {
    if (token) {
      localStorage.setItem('token', token)
    } else {
      localStorage.removeItem('token')
    }
    set({ token, isAuthenticated: !!token })
  },

  login: (user, token) => {
    localStorage.setItem('token', token)
    set({ user, token, isAuthenticated: true })
  },

  logout: () => {
    localStorage.removeItem('token')
    const { ws } = get()
    if (ws) {
      ws.close()
    }
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      rooms: [],
      currentRoom: null,
      messages: [],
      ws: null,
      wsConnected: false
    })
  },

  // 聊天室操作
  setRooms: (rooms) => set({ rooms }),

  addRoom: (room) => set((state) => ({
    rooms: [...state.rooms, room]
  })),

  setCurrentRoom: (room) => {
    set({ currentRoom: room, messages: [] })
    const { ws } = get()
    if (ws && room) {
      ws.send(JSON.stringify({ type: 'join', room_id: room.id }))
    }
  },

  // 消息操作
  setMessages: (messages) => set({ messages }),

  addMessage: (message) => set((state) => ({
    messages: [...state.messages, message]
  })),

  // 在线用户操作
  setOnlineUsers: (users) => set({ onlineUsers: users }),

  // WebSocket操作
  connectWebSocket: (token) => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`

    const ws = new WebSocket(wsUrl)

    ws.onopen = () => {
      console.log('WebSocket连接成功')
      set({ wsConnected: true })
    }

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      const state = get()

      switch (data.type) {
        case 'message':
          if (data.room_id === state.currentRoom?.id) {
            state.addMessage({
              id: Date.now(),
              sender_id: data.sender_id,
              sender_name: data.sender_name,
              room_id: data.room_id,
              content: data.content,
              message_type: 'text',
              is_read: false,
              created_at: data.timestamp
            })
          }
          break

        case 'system':
          state.addMessage({
            id: Date.now(),
            sender_id: 0,
            sender_name: '系统',
            room_id: data.room_id,
            content: data.content,
            message_type: 'system',
            is_read: true,
            created_at: data.timestamp
          })
          break

        case 'typing':
          // 可以添加正在输入的提示
          break

        case 'user_status':
          // 更新在线用户状态
          break

        case 'online_users':
          state.setOnlineUsers(data.users)
          break
      }
    }

    ws.onclose = () => {
      console.log('WebSocket连接关闭')
      set({ wsConnected: false })
    }

    ws.onerror = (error) => {
      console.error('WebSocket错误:', error)
    }

    set({ ws })
  },

  disconnectWebSocket: () => {
    const { ws } = get()
    if (ws) {
      ws.close()
      set({ ws: null, wsConnected: false })
    }
  },

  sendWebSocketMessage: (data) => {
    const { ws } = get()
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data))
    }
  }
}))
