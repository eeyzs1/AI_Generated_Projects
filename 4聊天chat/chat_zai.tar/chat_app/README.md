# 微信风格聊天应用 💬

一个基于 **FastAPI + WebSocket + React + TypeScript** 构建的实时聊天应用，实现了类似微信的核心功能。

![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)
![React](https://img.shields.io/badge/React-18.2+-61DAFB.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6.svg)

---

## 📖 目录

- [功能特性](#功能特性)
- [技术栈](#技术栈)
- [项目依赖](#项目依赖)
- [快速开始](#快速开始)
- [环境配置](#环境配置)
- [项目结构](#项目结构)
- [API文档](#api文档)
- [开发指南](#开发指南)
- [部署说明](#部署说明)
- [常见问题](#常见问题)

---

## ✨ 功能特性

### 用户系统
- 🔐 用户注册与登录
- 🔑 JWT Token 认证
- 👤 用户资料管理
- 🟢 在线状态显示

### 聊天室
- 🏠 创建聊天室
- 👥 邀请/移除成员
- 📋 聊天室列表
- ⚙️ 聊天室管理

### 实时消息
- 💬 实时消息发送/接收
- 🔔 系统通知
- ⌨️ 输入状态提示
- 📜 消息历史记录

### 界面特性
- 📱 响应式设计
- 🎨 微信风格UI
- 🌙 深色侧边栏
- 💫 平滑动画效果

---

## 🛠 技术栈

### 后端
| 技术 | 版本 | 描述 |
|------|------|------|
| Python | 3.11+ | 编程语言 |
| FastAPI | 0.104+ | 高性能Web框架 |
| SQLAlchemy | 2.0+ | ORM框架 |
| Pydantic | 2.5+ | 数据验证 |
| python-jose | 3.3+ | JWT处理 |
| passlib | 1.7+ | 密码加密 |
| uvicorn | 0.24+ | ASGI服务器 |
| websockets | 12.0+ | WebSocket支持 |

### 前端
| 技术 | 版本 | 描述 |
|------|------|------|
| React | 18.2+ | UI框架 |
| TypeScript | 5.0+ | 类型系统 |
| Vite | 5.0+ | 构建工具 |
| Zustand | 4.4+ | 状态管理 |
| Axios | 1.6+ | HTTP客户端 |
| React Router | 6.20+ | 路由管理 |

### 数据库
| 数据库 | 描述 |
|--------|------|
| SQLite | 默认数据库（开发环境） |
| MySQL 8.0 | 生产环境推荐 |

---

## 📦 项目依赖

### 后端依赖 (requirements.txt)

```txt
# Web框架
fastapi==0.104.1
uvicorn[standard]==0.24.0

# 数据库
sqlalchemy==2.0.23
pymysql==1.1.0          # MySQL驱动
aiomysql==0.2.0         # 异步MySQL驱动

# 数据验证
pydantic==2.5.2
pydantic[email]==2.5.2

# 认证
python-jose[cryptography]==3.3.0  # JWT
passlib[bcrypt]==1.7.4             # 密码加密

# WebSocket
websockets==12.0

# 其他
python-multipart==0.0.6  # 表单处理
```

### 前端依赖 (package.json)

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    "axios": "^1.6.2",
    "zustand": "^4.4.7"
  },
  "devDependencies": {
    "@types/react": "^18.2.37",
    "@types/react-dom": "^18.2.15",
    "@vitejs/plugin-react": "^4.2.0",
    "typescript": "^5.2.2",
    "vite": "^5.0.0"
  }
}
```

---

## 🚀 快速开始

### 前置要求

- Python 3.11+ 
- Node.js 18+ 
- npm 或 yarn
- (可选) Docker & Docker Compose

---

### 方式一：本地开发

#### 1. 克隆项目

```bash
git clone <repository-url>
cd chat_app
```

#### 2. 后端设置

```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
# Linux/macOS:
source venv/bin/activate
# Windows:
# venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 启动后端服务
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

后端服务将在 http://localhost:8000 启动

#### 3. 前端设置

```bash
# 进入前端目录
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端服务将在 http://localhost:3000 启动

#### 4. 访问应用

打开浏览器访问 http://localhost:3000

---

### 方式二：Docker 部署

#### 使用 Docker Compose（推荐）

```bash
# 启动所有服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

服务将启动在：
- 应用: http://localhost:8000
- MySQL: localhost:3306

#### 仅构建应用镜像

```bash
# 构建镜像
docker build -t chat-app .

# 运行容器
docker run -d -p 8000:8000 chat-app
```

---

## ⚙️ 环境配置

### 环境变量

创建 `.env` 文件（参考 `.env.example`）：

```bash
# 数据库配置
# SQLite (默认)
DATABASE_URL=sqlite:///./chat_app.db

# MySQL (生产环境)
# DATABASE_URL=mysql+pymysql://user:password@localhost:3306/chat_db

# JWT配置
SECRET_KEY=your-super-secret-key-change-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_HOURS=24
```

### 数据库配置

#### SQLite（默认）
无需额外配置，首次启动自动创建数据库文件。

#### MySQL
1. 创建数据库：
```sql
CREATE DATABASE chat_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chat_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON chat_db.* TO 'chat_user'@'localhost';
FLUSH PRIVILEGES;
```

2. 设置环境变量：
```bash
export DATABASE_URL="mysql+pymysql://chat_user:your_password@localhost:3306/chat_db"
```

---

## 📁 项目结构

```
chat_app/
├── main.py                    # FastAPI主入口
├── database.py                # 数据库配置
├── requirements.txt           # Python依赖
├── Dockerfile                 # Docker配置
├── docker-compose.yml         # Docker编排
├── .env.example              # 环境变量模板
├── README.md                 # 项目说明
├── arch.md                   # 架构文档
│
├── models/                    # 数据模型
│   ├── __init__.py
│   ├── user.py               # 用户模型
│   ├── room.py               # 聊天室模型
│   └── message.py            # 消息模型
│
├── schemas/                   # 数据验证
│   ├── __init__.py
│   ├── user.py               # 用户Schema
│   ├── room.py               # 聊天室Schema
│   └── message.py            # 消息Schema
│
├── services/                  # 业务逻辑
│   ├── __init__.py
│   ├── auth_service.py       # 认证服务
│   ├── chat_service.py       # 聊天服务
│   └── ws_service.py         # WebSocket服务
│
├── tests/                     # 测试文件
│   ├── __init__.py
│   ├── conftest.py           # 测试配置
│   ├── test_auth.py          # 认证测试
│   ├── test_chat.py          # 聊天测试
│   └── test_websocket.py     # WebSocket测试
│
└── frontend/                  # 前端应用
    ├── index.html
    ├── package.json
    ├── vite.config.ts
    ├── tsconfig.json
    └── src/
        ├── main.tsx          # 入口
        ├── App.tsx           # 根组件
        ├── Login.tsx         # 登录
        ├── Register.tsx      # 注册
        ├── ChatRoom.tsx      # 聊天室
        ├── UserList.tsx      # 用户列表
        ├── store.ts          # 状态管理
        ├── api.ts            # API封装
        └── index.css         # 样式
```

---

## 📚 API文档

启动后端服务后，访问以下地址查看交互式API文档：

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### 主要接口

#### 认证接口
| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/auth/register` | 用户注册 |
| POST | `/api/auth/login` | 用户登录 |
| POST | `/api/auth/logout` | 用户登出 |
| GET | `/api/auth/me` | 获取当前用户 |

#### 聊天室接口
| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/rooms` | 创建聊天室 |
| GET | `/api/rooms` | 获取聊天室列表 |
| GET | `/api/rooms/my` | 获取我的聊天室 |
| GET | `/api/rooms/{id}` | 获取聊天室详情 |
| POST | `/api/rooms/{id}/join` | 加入聊天室 |

#### 消息接口
| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/messages` | 发送消息 |
| GET | `/api/rooms/{id}/messages` | 获取消息列表 |

#### WebSocket
| 端点 | 描述 |
|------|------|
| `/ws?token={jwt}` | WebSocket连接 |

---

## 🔧 开发指南

### 运行测试

```bash
# 安装测试依赖
pip install pytest pytest-asyncio httpx

# 运行所有测试
pytest

# 运行特定测试
pytest tests/test_auth.py

# 查看覆盖率
pytest --cov=. tests/
```

### 代码风格

```bash
# 安装开发工具
pip install black flake8 isort

# 格式化代码
black .

# 检查代码
flake8 .

# 排序导入
isort .
```

### 添加新API

1. 在 `schemas/` 中定义请求/响应模型
2. 在 `models/` 中定义数据模型（如需要）
3. 在 `services/` 中实现业务逻辑
4. 在 `main.py` 中添加路由

### 添加新功能模块

1. 创建模型：`models/new_model.py`
2. 创建Schema：`schemas/new_schema.py`
3. 创建服务：`services/new_service.py`
4. 注册路由：`main.py`

---

## 🐳 部署说明

### Docker生产部署

1. 修改 `.env` 文件：
```bash
DATABASE_URL=mysql+pymysql://user:password@mysql:3306/chat_db
SECRET_KEY=your-production-secret-key
```

2. 构建并启动：
```bash
docker-compose -f docker-compose.yml up -d --build
```

### 传统部署

1. 安装依赖
2. 配置环境变量
3. 使用 Gunicorn + Uvicorn：
```bash
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000
```

4. 使用 Nginx 反向代理
5. 前端构建后部署到静态服务器

---

## ❓ 常见问题

### Q: 数据库初始化失败？
A: 确保 `data/` 目录存在且有写入权限：
```bash
mkdir -p data
chmod 755 data
```

### Q: WebSocket连接失败？
A: 检查以下几点：
1. Token是否有效
2. 后端服务是否启动
3. 防火墙是否允许WebSocket

### Q: 前端无法连接后端？
A: 检查 Vite 代理配置（`vite.config.ts`）：
```typescript
server: {
  proxy: {
    '/api': { target: 'http://localhost:8000' }
  }
}
```

### Q: 如何修改默认端口？
A: 
- 后端：`uvicorn main:app --port 你的端口`
- 前端：修改 `vite.config.ts` 中的 `server.port`

---

## 📄 License

MIT License

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！
