"""
FastAPI主入口文件
类似微信的聊天应用
"""
import os
from typing import List
from fastapi import FastAPI, Depends, HTTPException, status, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from pydantic import BaseModel

from database import get_db, init_db
from models.user import User
from models.room import Room
from models.message import Message
from schemas import (
    UserCreate, UserLogin, UserResponse, UserSimple,
    RoomCreate, RoomUpdate, RoomResponse, RoomDetail, RoomMember,
    MessageCreate, MessageResponse
)
from services import AuthService, ChatService, manager, WebSocketService

# 创建FastAPI应用
app = FastAPI(
    title="微信风格聊天应用",
    description="一个使用FastAPI + WebSocket构建的实时聊天应用",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境中应该限制来源
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 安全方案
security = HTTPBearer()


# ==================== 依赖函数 ====================

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """
    获取当前登录用户的依赖函数
    """
    token = credentials.credentials
    return AuthService.get_current_user(db, token)


# ==================== 根路径 ====================

@app.get("/")
async def root():
    """
    根路径
    """
    return {"message": "欢迎使用微信风格聊天应用API", "version": "1.0.0"}


# ==================== 用户认证相关 ====================

@app.post("/api/auth/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    用户注册
    """
    user = AuthService.register(db, user_data)
    return UserResponse.from_orm(user)


@app.post("/api/auth/login")
async def login(login_data: UserLogin, db: Session = Depends(get_db)):
    """
    用户登录
    """
    return AuthService.login(db, login_data.username, login_data.password)


@app.post("/api/auth/logout")
async def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    用户登出
    """
    # 通知其他用户
    await WebSocketService.notify_user_status(
        current_user.id, False, current_user.username
    )
    # 断开WebSocket连接
    manager.disconnect(current_user.id)
    # 更新数据库状态
    AuthService.logout(db, current_user.id)
    return {"message": "登出成功"}


@app.get("/api/auth/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    """
    获取当前用户信息
    """
    return UserResponse.from_orm(current_user)


# ==================== 用户管理 ====================

@app.get("/api/users", response_model=List[UserSimple])
async def get_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取用户列表
    """
    users = db.query(User).offset(skip).limit(limit).all()
    return [UserSimple.from_orm(u) for u in users]


@app.get("/api/users/online", response_model=List[UserSimple])
async def get_online_users(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取在线用户列表
    """
    online_user_ids = manager.get_online_users()
    users = db.query(User).filter(User.id.in_(online_user_ids)).all()
    return [UserSimple.from_orm(u) for u in users]


# ==================== 聊天室相关 ====================

@app.post("/api/rooms", response_model=RoomResponse, status_code=status.HTTP_201_CREATED)
async def create_room(
    room_data: RoomCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    创建聊天室
    """
    room = ChatService.create_room(db, room_data, current_user.id)
    response = RoomResponse.from_orm(room)
    response.member_count = len(room.members)
    return response


@app.get("/api/rooms", response_model=List[RoomResponse])
async def get_rooms(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取聊天室列表
    """
    rooms = ChatService.get_rooms(db, skip, limit)
    result = []
    for room in rooms:
        response = RoomResponse.from_orm(room)
        response.member_count = len(room.members)
        result.append(response)
    return result


@app.get("/api/rooms/my", response_model=List[RoomResponse])
async def get_my_rooms(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取我加入的聊天室
    """
    rooms = ChatService.get_user_rooms(db, current_user.id)
    result = []
    for room in rooms:
        response = RoomResponse.from_orm(room)
        response.member_count = len(room.members)
        result.append(response)
    return result


@app.get("/api/rooms/{room_id}", response_model=RoomDetail)
async def get_room(
    room_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取聊天室详情
    """
    room = ChatService.get_room_by_id(db, room_id)
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="聊天室不存在"
        )

    response = RoomDetail.from_orm(room)
    response.member_count = len(room.members)
    response.members = [UserSimple.from_orm(m) for m in room.members]
    return response


@app.put("/api/rooms/{room_id}", response_model=RoomResponse)
async def update_room(
    room_id: int,
    room_data: RoomUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    更新聊天室信息
    """
    room = ChatService.update_room(db, room_id, room_data, current_user.id)
    response = RoomResponse.from_orm(room)
    response.member_count = len(room.members)
    return response


@app.delete("/api/rooms/{room_id}")
async def delete_room(
    room_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    删除聊天室
    """
    ChatService.delete_room(db, room_id, current_user.id)
    return {"message": "聊天室已删除"}


@app.post("/api/rooms/{room_id}/members")
async def add_room_member(
    room_id: int,
    member_data: RoomMember,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    添加聊天室成员
    """
    ChatService.add_member(db, room_id, current_user.id, member_data.user_id)
    return {"message": "成员添加成功"}


@app.delete("/api/rooms/{room_id}/members/{member_id}")
async def remove_room_member(
    room_id: int,
    member_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    移除聊天室成员
    """
    ChatService.remove_member(db, room_id, current_user.id, member_id)
    return {"message": "成员移除成功"}


@app.post("/api/rooms/{room_id}/join")
async def join_room(
    room_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    加入聊天室
    """
    ChatService.add_member(db, room_id, current_user.id, current_user.id)
    return {"message": "加入成功"}


# ==================== 消息相关 ====================

@app.post("/api/messages", response_model=MessageResponse, status_code=status.HTTP_201_CREATED)
async def send_message(
    message_data: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    发送消息
    """
    message = ChatService.send_message(db, message_data, current_user.id)
    response = MessageResponse.from_orm(message)
    response.sender_name = current_user.username
    return response


@app.get("/api/rooms/{room_id}/messages", response_model=List[MessageResponse])
async def get_room_messages(
    room_id: int,
    skip: int = 0,
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取聊天室消息
    """
    messages = ChatService.get_room_messages(db, room_id, current_user.id, skip, limit)
    result = []
    for msg in reversed(messages):  # 按时间正序返回
        response = MessageResponse.from_orm(msg)
        response.sender_name = msg.sender.username if msg.sender else "Unknown"
        result.append(response)
    return result


@app.delete("/api/messages/{message_id}")
async def delete_message(
    message_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    删除消息
    """
    ChatService.delete_message(db, message_id, current_user.id)
    return {"message": "消息已删除"}


# ==================== WebSocket ====================

class WebSocketAuth(BaseModel):
    """
    WebSocket认证数据
    """
    token: str


@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = None
):
    """
    WebSocket连接端点
    """
    if not token:
        await websocket.close(code=4001, reason="未提供认证令牌")
        return

    # 验证token
    db = next(get_db())
    try:
        user = AuthService.get_current_user(db, token)
    except HTTPException:
        await websocket.close(code=4001, reason="无效的认证令牌")
        return

    # 建立连接
    await manager.connect(websocket, user.id)

    # 更新用户在线状态
    user.is_online = True
    db.commit()

    # 通知其他用户上线
    await WebSocketService.notify_user_status(user.id, True, user.username)

    try:
        while True:
            # 接收消息
            data = await websocket.receive_json()

            # 处理消息
            await WebSocketService.handle_message(db, user.id, data)

    except WebSocketDisconnect:
        # 用户断开连接
        manager.disconnect(user.id)

        # 更新用户离线状态
        user = db.query(User).filter(User.id == user.id).first()
        if user:
            user.is_online = False
            db.commit()

            # 通知其他用户下线
            await WebSocketService.notify_user_status(user.id, False, user.username)

    except Exception as e:
        print(f"WebSocket错误: {e}")
        manager.disconnect(user.id)


# ==================== 启动和关闭事件 ====================

@app.on_event("startup")
async def startup_event():
    """
    应用启动时的初始化
    """
    # 初始化数据库
    init_db()
    print("数据库初始化完成")


@app.on_event("shutdown")
async def shutdown_event():
    """
    应用关闭时的清理
    """
    print("应用正在关闭...")


# ==================== 静态文件服务 ====================

# 挂载静态文件目录（用于前端）
frontend_path = os.path.join(os.path.dirname(__file__), "frontend", "public")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")


# ==================== 运行应用 ====================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
