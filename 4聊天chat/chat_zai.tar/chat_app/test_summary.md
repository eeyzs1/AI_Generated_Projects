# 测试文档

## 📋 目录
- [测试概述](#测试概述)
- [测试环境配置](#测试环境配置)
- [测试文件说明](#测试文件说明)
- [测试用例列表](#测试用例列表)
- [如何运行测试](#如何运行测试)
- [测试覆盖率](#测试覆盖率)
- [持续集成](#持续集成)

---

## 测试概述

本项目使用 **pytest** 作为测试框架，对以下模块进行全面测试：

| 模块 | 测试文件 | 测试数量 |
|------|----------|----------|
| 认证模块 | test_auth.py | 15+ |
| 聊天模块 | test_chat.py | 15+ |
| WebSocket | test_websocket.py | 10+ |

### 测试覆盖范围
- ✅ 用户注册与登录
- ✅ JWT Token 认证
- ✅ 聊天室 CRUD 操作
- ✅ 消息发送与接收
- ✅ WebSocket 连接与通信
- ✅ 多用户实时交互

---

## 测试环境配置

### 测试依赖

项目测试依赖已包含在 `requirements.txt` 中：

```txt
# 测试框架
pytest==7.4.3
pytest-asyncio==0.21.1
httpx==0.25.2
```

### 安装测试依赖

```bash
# 进入项目目录
cd chat_app

# 安装所有依赖（包括测试依赖）
pip install -r requirements.txt

# 或仅安装测试依赖
pip install pytest pytest-asyncio httpx
```

### 测试数据库配置

测试使用内存 SQLite 数据库，无需额外配置：

```python
# tests/conftest.py
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"
```

每次测试运行时会自动创建和销毁数据库表，确保测试隔离。

---

## 测试文件说明

### 目录结构

```
tests/
├── __init__.py          # 模块初始化
├── conftest.py          # 测试配置和夹具
├── test_auth.py         # 认证模块测试
├── test_chat.py         # 聊天模块测试
└── test_websocket.py    # WebSocket测试
```

### conftest.py - 测试配置

提供测试夹具（Fixtures）：

| 夹具名称 | 说明 |
|----------|------|
| `db` | 测试数据库会话 |
| `client` | FastAPI测试客户端 |
| `test_user_data` | 测试用户数据 |
| `test_user_data2` | 第二个测试用户数据 |
| `registered_user` | 已注册的用户 |
| `auth_header` | 认证请求头 |
| `test_room_data` | 测试聊天室数据 |

### test_auth.py - 认证测试

测试类结构：

```
TestUserRegistration
├── test_register_success
├── test_register_duplicate_username
├── test_register_duplicate_email
├── test_register_short_username
├── test_register_weak_password
└── test_register_invalid_email

TestUserLogin
├── test_login_success
├── test_login_wrong_password
└── test_login_nonexistent_user

TestTokenValidation
├── test_get_current_user_success
├── test_get_current_user_invalid_token
├── test_get_current_user_no_token
└── test_get_current_user_expired_token

TestUserLogout
├── test_logout_success
└── test_logout_without_auth

TestUserAPI
├── test_get_users_list
└── test_get_online_users
```

### test_chat.py - 聊天测试

测试类结构：

```
TestRoomCreation
├── test_create_room_success
├── test_create_room_without_auth
└── test_create_room_with_members

TestRoomQuery
├── test_get_rooms_list
├── test_get_my_rooms
├── test_get_room_by_id
└── test_get_nonexistent_room

TestRoomManagement
├── test_update_room
├── test_delete_room
└── test_join_room

TestMessageAPI
├── test_send_message
├── test_send_message_to_nonexistent_room
├── test_get_room_messages
└── test_delete_message

TestRoomMembers
├── test_add_member
└── test_remove_member
```

### test_websocket.py - WebSocket测试

测试类结构：

```
TestWebSocket
├── test_websocket_connect_with_valid_token
├── test_websocket_connect_without_token
├── test_websocket_connect_with_invalid_token
├── test_websocket_join_room
├── test_websocket_send_message
├── test_websocket_typing_indicator
└── test_websocket_leave_room

TestWebSocketMultipleUsers
└── test_multiple_users_same_room

TestWebSocketOnlineUsers
└── test_get_online_users_via_websocket
```

---

## 测试用例列表

### 认证模块测试用例

| ID | 测试用例 | 预期结果 |
|----|----------|----------|
| AUTH-001 | 正常注册 | 返回201，创建用户成功 |
| AUTH-002 | 重复用户名注册 | 返回400，提示用户名已存在 |
| AUTH-003 | 重复邮箱注册 | 返回400，提示邮箱已存在 |
| AUTH-004 | 用户名过短 | 返回422，验证失败 |
| AUTH-005 | 密码无数字 | 返回422，验证失败 |
| AUTH-006 | 无效邮箱格式 | 返回422，验证失败 |
| AUTH-007 | 正常登录 | 返回200，返回Token |
| AUTH-008 | 错误密码登录 | 返回401，认证失败 |
| AUTH-009 | 不存在用户登录 | 返回401，认证失败 |
| AUTH-010 | 有效Token获取用户 | 返回200，返回用户信息 |
| AUTH-011 | 无效Token | 返回401，认证失败 |
| AUTH-012 | 无Token | 返回403，禁止访问 |
| AUTH-013 | 正常登出 | 返回200，登出成功 |

### 聊天模块测试用例

| ID | 测试用例 | 预期结果 |
|----|----------|----------|
| ROOM-001 | 创建聊天室 | 返回201，创建成功 |
| ROOM-002 | 未认证创建 | 返回403，禁止访问 |
| ROOM-003 | 创建并添加成员 | 返回201，成员添加成功 |
| ROOM-004 | 获取聊天室列表 | 返回200，返回列表 |
| ROOM-005 | 获取我的聊天室 | 返回200，返回列表 |
| ROOM-006 | 获取聊天室详情 | 返回200，返回详情 |
| ROOM-007 | 获取不存在聊天室 | 返回404，未找到 |
| ROOM-008 | 更新聊天室 | 返回200，更新成功 |
| ROOM-009 | 删除聊天室 | 返回200，删除成功 |
| ROOM-010 | 加入聊天室 | 返回200，加入成功 |
| MSG-001 | 发送消息 | 返回201，发送成功 |
| MSG-002 | 向不存在房间发消息 | 返回403，无权限 |
| MSG-003 | 获取消息列表 | 返回200，返回列表 |
| MSG-004 | 删除消息 | 返回200，删除成功 |

### WebSocket测试用例

| ID | 测试用例 | 预期结果 |
|----|----------|----------|
| WS-001 | 有效Token连接 | 连接成功 |
| WS-002 | 无Token连接 | 连接失败 |
| WS-003 | 无效Token连接 | 连接失败 |
| WS-004 | 加入聊天室 | 收到系统消息 |
| WS-005 | 发送消息 | 收到消息回显 |
| WS-006 | 输入状态 | 收到typing消息 |
| WS-007 | 离开聊天室 | 收到系统消息 |
| WS-008 | 多用户同房间 | 都能收到消息 |
| WS-009 | 获取在线用户 | 返回用户列表 |

---

## 如何运行测试

### 运行所有测试

```bash
# 进入项目目录
cd chat_app

# 运行所有测试
pytest

# 显示详细信息
pytest -v

# 显示更详细的信息（包括print输出）
pytest -v -s
```

### 运行特定测试文件

```bash
# 只运行认证测试
pytest tests/test_auth.py

# 只运行聊天测试
pytest tests/test_chat.py

# 只运行WebSocket测试
pytest tests/test_websocket.py
```

### 运行特定测试类

```bash
# 只运行用户注册测试
pytest tests/test_auth.py::TestUserRegistration

# 只运行用户登录测试
pytest tests/test_auth.py::TestUserLogin
```

### 运行特定测试方法

```bash
# 只运行注册成功测试
pytest tests/test_auth.py::TestUserRegistration::test_register_success

# 只运行登录成功测试
pytest tests/test_auth.py::TestUserLogin::test_login_success
```

### 使用标记运行测试

```bash
# 运行标记为slow的测试
pytest -m slow

# 跳过标记为slow的测试
pytest -m "not slow"
```

---

## 测试覆盖率

### 安装覆盖率工具

```bash
pip install pytest-cov
```

### 生成覆盖率报告

```bash
# 生成覆盖率报告
pytest --cov=. tests/

# 生成详细报告
pytest --cov=. --cov-report=term-missing tests/

# 生成HTML报告
pytest --cov=. --cov-report=html tests/

# 查看HTML报告
open htmlcov/index.html  # macOS
# 或
start htmlcov/index.html  # Windows
```

### 覆盖率目标

| 模块 | 目标覆盖率 |
|------|------------|
| services/auth_service.py | 90%+ |
| services/chat_service.py | 85%+ |
| services/ws_service.py | 80%+ |
| 整体项目 | 80%+ |

---

## 持续集成

### GitHub Actions 配置示例

创建 `.github/workflows/test.yml`：

```yaml
name: Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3

    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt

    - name: Run tests
      run: |
        pytest --cov=. --cov-report=xml

    - name: Upload coverage
      uses: codecov/codecov-action@v3
```

---

## 测试最佳实践

### 1. 测试隔离
- 每个测试函数独立运行
- 使用夹具管理测试数据
- 测试后自动清理数据

### 2. 测试命名
```python
# 好的命名
def test_register_with_duplicate_username():
    pass

# 不好的命名
def test_register_1():
    pass
```

### 3. 断言清晰
```python
# 好的断言
assert response.status_code == 201
assert "access_token" in response.json()

# 不好的断言
assert response
```

### 4. 测试边界情况
- 正常情况 ✅
- 边界情况 ✅
- 错误情况 ✅
- 异常情况 ✅

---

## 常见问题

### Q: 测试运行失败？
```bash
# 检查依赖是否安装
pip install -r requirements.txt

# 检查Python版本
python --version  # 需要 3.11+
```

### Q: 数据库相关测试失败？
```bash
# 确保使用测试数据库（内存SQLite）
# 检查 conftest.py 配置
```

### Q: WebSocket测试超时？
```python
# 增加超时时间
pytest --timeout=60 tests/test_websocket.py
```

---

## 测试命令速查表

| 命令 | 说明 |
|------|------|
| `pytest` | 运行所有测试 |
| `pytest -v` | 详细输出 |
| `pytest -x` | 首次失败即停止 |
| `pytest --ff` | 先运行上次失败的测试 |
| `pytest -k "auth"` | 运行名称包含auth的测试 |
| `pytest --cov=.` | 生成覆盖率报告 |
| `pytest -n 4` | 并行运行（需安装pytest-xdist） |

---

## 联系方式

如有测试相关问题，请提交 Issue 或联系开发团队。
