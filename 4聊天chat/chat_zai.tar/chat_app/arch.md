# 微信风格聊天应用 - 架构文档

## 📋 目录
- [项目概述](#项目概述)
- [系统架构](#系统架构)
- [技术栈](#技术栈)
- [目录结构](#目录结构)
- [文件详细说明](#文件详细说明)
- [数据模型](#数据模型)
- [API接口](#api接口)
- [WebSocket通信](#websocket通信)
- [安全机制](#安全机制)

---

## 项目概述

本项目是一个基于 FastAPI + WebSocket + React 构建的实时聊天应用，实现了类似微信的核心功能，包括用户认证、聊天室管理、实时消息传递等功能。

### 核心特性
- 用户注册与登录（JWT认证）
- 聊天室创建与管理
- 实时消息传递（WebSocket）
- 在线用户状态管理
- 响应式前端界面

---

## 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│                          客户端层                                │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    React 前端应用                          │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────────────┐ │   │
│  │  │  登录   │ │  注册   │ │ 聊天室  │ │   用户列表      │ │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────────────┘ │   │
│  │                                                          │   │
│  │  ┌────────────────────────────────────────────────────┐ │   │
│  │  │              Zustand 状态管理                       │ │   │
│  │  └────────────────────────────────────────────────────┘ │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP / WebSocket
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                          服务端层                                │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    FastAPI 应用                           │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │   │
│  │  │  REST API   │  │  WebSocket  │  │    静态文件      │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    业务逻辑层                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │   │
│  │  │ 认证服务    │  │ 聊天服务    │  │  WebSocket服务   │  │   │
│  │  │AuthService  │  │ChatService  │  │  WSService      │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    数据访问层                             │   │
│  │  ┌───────────────────────────────────────────────────┐  │   │
│  │  │              SQLAlchemy ORM                        │  │   │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────────────────┐  │  │   │
│  │  │  │  User   │ │  Room   │ │     Message         │  │  │   │
│  │  │  └─────────┘ └─────────┘ └─────────────────────┘  │  │   │
│  │  └───────────────────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                          数据层                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              SQLite / MySQL 数据库                        │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 技术栈

### 后端技术
| 技术 | 版本 | 用途 |
|------|------|------|
| Python | 3.11+ | 编程语言 |
| FastAPI | 0.104+ | Web框架 |
| SQLAlchemy | 2.0+ | ORM框架 |
| Pydantic | 2.5+ | 数据验证 |
| python-jose | 3.3+ | JWT处理 |
| passlib | 1.7+ | 密码加密 |
| uvicorn | 0.24+ | ASGI服务器 |

### 前端技术
| 技术 | 版本 | 用途 |
|------|------|------|
| React | 18.2+ | UI框架 |
| TypeScript | 5.0+ | 类型系统 |
| Vite | 5.0+ | 构建工具 |
| Zustand | 4.4+ | 状态管理 |
| Axios | 1.6+ | HTTP客户端 |
| React Router | 6.20+ | 路由管理 |

---

## 目录结构

```
chat_app/
├── main.py                    # 应用入口
├── database.py                # 数据库配置
├── requirements.txt           # Python依赖
├── Dockerfile                 # Docker镜像配置
├── docker-compose.yml         # Docker编排配置
├── .env.example              # 环境变量模板
├── README.md                 # 项目说明
├── arch.md                   # 架构文档
│
├── models/                    # 数据模型层
│   ├── __init__.py           # 模块导出
│   ├── user.py               # 用户模型
│   ├── room.py               # 聊天室模型
│   └── message.py            # 消息模型
│
├── schemas/                   # 数据验证层
│   ├── __init__.py           # 模块导出
│   ├── user.py               # 用户Schema
│   ├── room.py               # 聊天室Schema
│   └── message.py            # 消息Schema
│
├── services/                  # 业务逻辑层
│   ├── __init__.py           # 模块导出
│   ├── auth_service.py       # 认证服务
│   ├── chat_service.py       # 聊天服务
│   └── ws_service.py         # WebSocket服务
│
├── tests/                     # 测试目录
│   ├── __init__.py
│   ├── conftest.py           # 测试配置
│   ├── test_auth.py          # 认证测试
│   ├── test_chat.py          # 聊天测试
│   └── test_websocket.py     # WebSocket测试
│
└── frontend/                  # 前端应用
    ├── index.html            # HTML模板
    ├── package.json          # Node依赖
    ├── vite.config.ts        # Vite配置
    ├── tsconfig.json         # TypeScript配置
    └── src/
        ├── main.tsx          # 入口文件
        ├── App.tsx           # 根组件
        ├── Login.tsx         # 登录页面
        ├── Register.tsx      # 注册页面
        ├── ChatRoom.tsx      # 聊天室页面
        ├── UserList.tsx      # 用户列表组件
        ├── store.ts          # 状态管理
        ├── api.ts            # API封装
        └── index.css         # 全局样式
```

---

## 文件详细说明

### 1. 后端核心文件

#### `main.py` - 应用入口
**作用**: FastAPI应用的主入口文件，负责：
- 创建FastAPI应用实例
- 配置CORS中间件
- 注册API路由
- 配置WebSocket端点
- 应用启动/关闭事件处理
- 静态文件服务

**关键代码结构**:
```python
app = FastAPI(title="微信风格聊天应用")

# CORS配置
app.add_middleware(CORSMiddleware, ...)

# REST API路由
@app.post("/api/auth/register")
@app.post("/api/auth/login")
@app.get("/api/rooms")
# ... 更多路由

# WebSocket端点
@app.websocket("/ws")

# 启动事件
@app.on_event("startup")
```

---

#### `database.py` - 数据库配置
**作用**: 数据库连接和会话管理：
- 创建SQLAlchemy引擎
- 配置会话工厂
- 定义Base模型基类
- 提供数据库依赖注入函数
- 初始化数据库表

**关键代码结构**:
```python
DATABASE_URL = "sqlite:///./chat_app.db"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

def get_db():  # 依赖注入
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

---

#### `models/user.py` - 用户模型
**作用**: 定义用户数据表结构：
- 用户基本信息（用户名、邮箱、密码）
- 在线状态管理
- 关联聊天室和消息

**字段说明**:
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Integer | 主键 |
| username | String(50) | 用户名，唯一 |
| email | String(100) | 邮箱，唯一 |
| hashed_password | String(255) | 加密密码 |
| avatar | String(255) | 头像URL |
| is_active | Boolean | 是否激活 |
| is_online | Boolean | 是否在线 |
| created_at | DateTime | 创建时间 |

---

#### `models/room.py` - 聊天室模型
**作用**: 定义聊天室数据表结构和成员关联：
- 聊天室基本信息
- 创建者关联
- 成员多对多关系

**字段说明**:
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Integer | 主键 |
| name | String(100) | 房间名称 |
| description | Text | 房间描述 |
| creator_id | Integer | 创建者ID |
| is_private | Integer | 是否私密 |
| members | Relationship | 成员列表 |

**关联表 `room_members`**:
- room_id: 聊天室ID
- user_id: 用户ID
- joined_at: 加入时间

---

#### `models/message.py` - 消息模型
**作用**: 定义消息数据表结构：
- 消息内容存储
- 发送者关联
- 聊天室关联

**字段说明**:
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Integer | 主键 |
| sender_id | Integer | 发送者ID |
| room_id | Integer | 聊天室ID |
| content | Text | 消息内容 |
| message_type | String | 消息类型 |
| is_read | Integer | 是否已读 |
| created_at | DateTime | 创建时间 |

**消息类型枚举**:
- `TEXT`: 文本消息
- `IMAGE`: 图片消息
- `FILE`: 文件消息
- `SYSTEM`: 系统消息

---

#### `schemas/user.py` - 用户Schema
**作用**: 定义用户相关的Pydantic模型：
- 请求数据验证
- 响应数据序列化

**Schema类说明**:
| 类名 | 用途 |
|------|------|
| UserBase | 基础字段（用户名、邮箱） |
| UserCreate | 注册请求（含密码） |
| UserLogin | 登录请求 |
| UserUpdate | 更新请求 |
| UserResponse | 完整响应 |
| UserSimple | 简单响应（列表用） |
| Token | JWT令牌响应 |

---

#### `schemas/room.py` - 聊天室Schema
**作用**: 定义聊天室相关的Pydantic模型

**Schema类说明**:
| 类名 | 用途 |
|------|------|
| RoomBase | 基础字段 |
| RoomCreate | 创建请求 |
| RoomUpdate | 更新请求 |
| RoomResponse | 基本响应 |
| RoomDetail | 详细响应（含成员） |
| RoomMember | 成员操作请求 |

---

#### `schemas/message.py` - 消息Schema
**作用**: 定义消息相关的Pydantic模型

**Schema类说明**:
| 类名 | 用途 |
|------|------|
| MessageBase | 基础字段 |
| MessageCreate | 发送请求 |
| MessageResponse | 消息响应 |
| MessageList | 消息列表响应 |
| WebSocketMessage | WebSocket消息格式 |

---

#### `services/auth_service.py` - 认证服务
**作用**: 处理所有认证相关的业务逻辑

**主要方法**:
| 方法 | 功能 |
|------|------|
| `verify_password()` | 验证密码 |
| `get_password_hash()` | 生成密码哈希 |
| `create_access_token()` | 创建JWT令牌 |
| `decode_token()` | 解码JWT令牌 |
| `register()` | 用户注册 |
| `login()` | 用户登录 |
| `logout()` | 用户登出 |
| `get_current_user()` | 获取当前用户 |

**安全配置**:
```python
SECRET_KEY = "your-secret-key"  # 生产环境需更换
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24
```

---

#### `services/chat_service.py` - 聊天服务
**作用**: 处理聊天室和消息的业务逻辑

**聊天室方法**:
| 方法 | 功能 |
|------|------|
| `create_room()` | 创建聊天室 |
| `get_room_by_id()` | 获取聊天室 |
| `get_rooms()` | 获取聊天室列表 |
| `get_user_rooms()` | 获取用户聊天室 |
| `update_room()` | 更新聊天室 |
| `delete_room()` | 删除聊天室 |
| `add_member()` | 添加成员 |
| `remove_member()` | 移除成员 |
| `is_room_member()` | 检查成员身份 |

**消息方法**:
| 方法 | 功能 |
|------|------|
| `send_message()` | 发送消息 |
| `get_room_messages()` | 获取聊天室消息 |
| `delete_message()` | 删除消息 |

---

#### `services/ws_service.py` - WebSocket服务
**作用**: 管理WebSocket连接和实时消息

**ConnectionManager类**:
| 属性/方法 | 功能 |
|-----------|------|
| `active_connections` | 活跃连接字典 |
| `room_users` | 聊天室用户映射 |
| `online_users` | 在线用户集合 |
| `connect()` | 建立连接 |
| `disconnect()` | 断开连接 |
| `send_personal_message()` | 发送私人消息 |
| `broadcast()` | 广播消息 |
| `broadcast_to_room()` | 广播到聊天室 |
| `join_room()` | 加入聊天室 |
| `leave_room()` | 离开聊天室 |
| `get_online_users()` | 获取在线用户 |

**WebSocketService类**:
| 方法 | 功能 |
|------|------|
| `handle_message()` | 处理WebSocket消息 |
| `notify_user_status()` | 通知用户状态变化 |

**消息类型**:
- `join`: 加入聊天室
- `leave`: 离开聊天室
- `message`: 聊天消息
- `typing`: 正在输入
- `online_users`: 在线用户列表
- `user_status`: 用户状态变化
- `system`: 系统消息

---

### 2. 前端核心文件

#### `src/App.tsx` - 根组件
**作用**: 应用根组件，负责：
- 路由配置
- 认证状态检查
- 受保护路由

**路由结构**:
```tsx
/login        → Login
/register     → Register
/chat         → ChatMain (受保护)
/chat/room/:id → ChatRoom (受保护)
/             → 重定向到 /login
```

---

#### `src/Login.tsx` - 登录页面
**作用**: 用户登录界面：
- 登录表单
- 表单验证
- 登录请求
- WebSocket连接初始化

---

#### `src/Register.tsx` - 注册页面
**作用**: 用户注册界面：
- 注册表单
- 密码强度验证
- 密码确认验证
- 注册请求

---

#### `src/ChatRoom.tsx` - 聊天室页面
**作用**: 聊天室主界面：
- 消息列表显示
- 消息发送表单
- 成员列表侧边栏
- WebSocket消息处理

**功能**:
- 实时消息接收
- 自动滚动到底部
- 系统消息显示
- 正在输入提示

---

#### `src/UserList.tsx` - 用户列表
**作用**: 显示用户列表：
- 在线用户显示
- 所有用户列表
- 在线状态标识

---

#### `src/store.ts` - 状态管理
**作用**: 使用Zustand管理全局状态

**状态结构**:
```typescript
interface AppState {
  // 用户状态
  user: User | null
  token: string | null
  isAuthenticated: boolean

  // 聊天室状态
  rooms: Room[]
  currentRoom: Room | null

  // 消息状态
  messages: Message[]

  // 在线用户
  onlineUsers: User[]

  // WebSocket
  ws: WebSocket | null
  wsConnected: boolean

  // 操作方法
  login(), logout()
  setRooms(), setCurrentRoom()
  addMessage(), setMessages()
  connectWebSocket(), sendWebSocketMessage()
}
```

---

#### `src/api.ts` - API封装
**作用**: 封装所有HTTP请求：
- Axios实例配置
- 请求拦截器（添加Token）
- 响应拦截器（处理401）
- API方法分组

**API分组**:
```typescript
authApi:    // 认证相关
  register(), login(), logout(), getMe()

userApi:    // 用户相关
  getUsers(), getOnlineUsers()

roomApi:    // 聊天室相关
  createRoom(), getRooms(), getMyRooms()
  getRoom(), updateRoom(), deleteRoom()
  addMember(), removeMember(), joinRoom()

messageApi: // 消息相关
  sendMessage(), getRoomMessages(), deleteMessage()
```

---

#### `src/index.css` - 全局样式
**作用**: 定义应用全局样式：
- CSS Reset
- 通用组件样式
- 布局样式
- 响应式适配

**样式模块**:
- 按钮样式 (.btn-*)
- 输入框样式 (.input)
- 认证页面样式 (.auth-*)
- 聊天界面样式 (.chat-*)
- 消息样式 (.message-*)
- 弹窗样式 (.modal)

---

### 3. 配置文件

#### `requirements.txt` - Python依赖
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
sqlalchemy==2.0.23
pydantic==2.5.2
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
websockets==12.0
```

---

#### `Dockerfile` - Docker配置
**多阶段构建**:
1. 阶段1: 构建前端（Node.js）
2. 阶段2: Python运行环境

**最终镜像包含**:
- Python 3.11
- 后端代码
- 前端构建产物

---

#### `docker-compose.yml` - Docker编排
**服务定义**:
- `mysql`: MySQL 8.0数据库
- `chat_app`: 聊天应用

**网络配置**:
- 自定义网络: chat_network
- 数据卷: mysql_data

---

## 数据模型

### ER图

```
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│    User     │       │    Room     │       │   Message   │
├─────────────┤       ├─────────────┤       ├─────────────┤
│ id (PK)     │       │ id (PK)     │       │ id (PK)     │
│ username    │       │ name        │       │ sender_id   │──┐
│ email       │       │ description │       │ room_id     │──┼──┐
│ password    │       │ creator_id  │──┐    │ content     │  │  │
│ avatar      │       │ is_private  │  │    │ type        │  │  │
│ is_active   │       │ created_at  │  │    │ created_at  │  │  │
│ is_online   │       └─────────────┘  │    └─────────────┘  │  │
│ created_at  │                        │                     │  │
└─────────────┘                        │                     │  │
       │                               │                     │  │
       │ 1:N                           │ N:1                 │  │
       └───────────────────────────────┘                     │  │
                                                             │  │
       ┌─────────────────────────────────────────────────────┘  │
       │  N:1                                                    │
       └─────────────────────────────────────────────────────────┘

┌─────────────────┐
│  room_members   │  (多对多关联表)
├─────────────────┤
│ room_id (PK,FK) │
│ user_id (PK,FK) │
│ joined_at       │
└─────────────────┘
```

---

## API接口

### 认证接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/auth/register | 用户注册 |
| POST | /api/auth/login | 用户登录 |
| POST | /api/auth/logout | 用户登出 |
| GET | /api/auth/me | 获取当前用户 |

### 用户接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/users | 获取用户列表 |
| GET | /api/users/online | 获取在线用户 |

### 聊天室接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/rooms | 创建聊天室 |
| GET | /api/rooms | 获取聊天室列表 |
| GET | /api/rooms/my | 获取我的聊天室 |
| GET | /api/rooms/{id} | 获取聊天室详情 |
| PUT | /api/rooms/{id} | 更新聊天室 |
| DELETE | /api/rooms/{id} | 删除聊天室 |
| POST | /api/rooms/{id}/join | 加入聊天室 |
| POST | /api/rooms/{id}/members | 添加成员 |
| DELETE | /api/rooms/{id}/members/{uid} | 移除成员 |

### 消息接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/messages | 发送消息 |
| GET | /api/rooms/{id}/messages | 获取消息列表 |
| DELETE | /api/messages/{id} | 删除消息 |

---

## WebSocket通信

### 连接
```
ws://host/ws?token={jwt_token}
```

### 消息格式

**发送消息**:
```json
{
  "type": "message",
  "room_id": 1,
  "content": "Hello!"
}
```

**加入聊天室**:
```json
{
  "type": "join",
  "room_id": 1
}
```

**离开聊天室**:
```json
{
  "type": "leave",
  "room_id": 1
}
```

**正在输入**:
```json
{
  "type": "typing",
  "room_id": 1
}
```

### 接收消息格式

**聊天消息**:
```json
{
  "type": "message",
  "sender_id": 1,
  "sender_name": "张三",
  "room_id": 1,
  "content": "Hello!",
  "timestamp": "2024-01-01T12:00:00"
}
```

**系统消息**:
```json
{
  "type": "system",
  "content": "张三 加入了聊天室",
  "room_id": 1,
  "timestamp": "2024-01-01T12:00:00"
}
```

**用户状态**:
```json
{
  "type": "user_status",
  "user_id": 1,
  "username": "张三",
  "is_online": true,
  "content": "张三 上线了",
  "timestamp": "2024-01-01T12:00:00"
}
```

---

## 安全机制

### 密码安全
- 使用 bcrypt 算法加密
- 自动加盐处理
- 不可逆加密

### JWT认证
- HS256 算法签名
- 24小时过期时间
- Bearer Token 方式传递

### API安全
- 受保护路由需要Token
- Token自动续期
- 401自动跳转登录

### CORS配置
```python
allow_origins: ["*"]  # 生产环境需限制
allow_credentials: True
allow_methods: ["*"]
allow_headers: ["*"]
```

---

## 扩展建议

1. **数据库优化**
   - 添加消息索引
   - 实现消息分页优化
   - 添加缓存层

2. **功能扩展**
   - 图片/文件上传
   - 消息已读回执
   - 私聊功能
   - 群组管理

3. **性能优化**
   - WebSocket心跳检测
   - 消息队列
   - 负载均衡

4. **安全增强**
   - HTTPS支持
   - Rate Limiting
   - XSS防护
