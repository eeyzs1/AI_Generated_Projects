"""
聊天室模型
定义聊天室的数据结构
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Table, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


# 聊天室成员关联表（多对多）
room_members = Table(
    'room_members',
    Base.metadata,
    Column('room_id', Integer, ForeignKey('rooms.id', ondelete='CASCADE'), primary_key=True),
    Column('user_id', Integer, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True),
    Column('joined_at', DateTime(timezone=True), server_default=func.now())
)


class Room(Base):
    """
    聊天室表模型
    """
    __tablename__ = "rooms"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(100), nullable=False, comment="房间名称")
    description = Column(Text, nullable=True, comment="房间描述")
    creator_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="创建者ID")
    is_private = Column(Integer, default=0, comment="是否私密(0:公开, 1:私密)")
    avatar = Column(String(255), nullable=True, comment="房间头像URL")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="创建时间")
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), comment="更新时间")

    # 关联关系
    creator = relationship("User", foreign_keys=[creator_id], backref="created_rooms")
    members = relationship("User", secondary=room_members, back_populates="rooms")
    messages = relationship("Message", back_populates="room", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Room(id={self.id}, name='{self.name}', creator_id={self.creator_id})>"
