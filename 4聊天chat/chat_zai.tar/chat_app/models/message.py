"""
消息模型
定义消息的数据结构
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base
import enum


class MessageType(enum.Enum):
    """
    消息类型枚举
    """
    TEXT = "text"  # 文本消息
    IMAGE = "image"  # 图片消息
    FILE = "file"  # 文件消息
    SYSTEM = "system"  # 系统消息


class Message(Base):
    """
    消息表模型
    """
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    sender_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="发送者ID")
    room_id = Column(Integer, ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False, comment="聊天室ID")
    content = Column(Text, nullable=False, comment="消息内容")
    message_type = Column(
        String(20),
        default=MessageType.TEXT.value,
        comment="消息类型"
    )
    is_read = Column(Integer, default=0, comment="是否已读(0:未读, 1:已读)")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="创建时间")

    # 关联关系
    sender = relationship("User", back_populates="messages")
    room = relationship("Room", back_populates="messages")

    def __repr__(self):
        return f"<Message(id={self.id}, sender_id={self.sender_id}, room_id={self.room_id})>"

    def to_dict(self):
        """
        转换为字典格式
        用于WebSocket消息传输
        """
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "sender_name": self.sender.username if self.sender else None,
            "room_id": self.room_id,
            "content": self.content,
            "message_type": self.message_type,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }
