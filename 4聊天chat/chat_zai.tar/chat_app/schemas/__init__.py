"""
Schemas模块初始化
导出所有Pydantic模型
"""
from schemas.user import (
    UserBase,
    UserCreate,
    UserLogin,
    UserUpdate,
    UserResponse,
    UserSimple,
    Token,
    TokenData
)
from schemas.room import (
    RoomBase,
    RoomCreate,
    RoomUpdate,
    RoomResponse,
    RoomDetail,
    RoomMember
)
from schemas.message import (
    MessageBase,
    MessageCreate,
    MessageResponse,
    MessageList,
    WebSocketMessage
)

__all__ = [
    # User schemas
    "UserBase",
    "UserCreate",
    "UserLogin",
    "UserUpdate",
    "UserResponse",
    "UserSimple",
    "Token",
    "TokenData",
    # Room schemas
    "RoomBase",
    "RoomCreate",
    "RoomUpdate",
    "RoomResponse",
    "RoomDetail",
    "RoomMember",
    # Message schemas
    "MessageBase",
    "MessageCreate",
    "MessageResponse",
    "MessageList",
    "WebSocketMessage"
]
