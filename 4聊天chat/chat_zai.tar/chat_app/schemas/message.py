"""
消息相关的Pydantic schemas
用于数据验证和序列化
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class MessageBase(BaseModel):
    """
    消息基础模型
    """
    content: str = Field(..., min_length=1, max_length=5000, description="消息内容")
    message_type: str = Field(default="text", description="消息类型")


class MessageCreate(MessageBase):
    """
    消息创建模型
    """
    room_id: int = Field(..., description="聊天室ID")


class MessageResponse(MessageBase):
    """
    消息响应模型
    """
    id: int
    sender_id: int
    sender_name: Optional[str] = None
    room_id: int
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class MessageList(BaseModel):
    """
    消息列表响应模型
    """
    messages: list[MessageResponse]
    total: int
    page: int
    page_size: int


class WebSocketMessage(BaseModel):
    """
    WebSocket消息模型
    """
    type: str = Field(..., description="消息类型: message, join, leave, typing")
    room_id: Optional[int] = None
    sender_id: Optional[int] = None
    sender_name: Optional[str] = None
    content: Optional[str] = None
    timestamp: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
