"""
用户相关的Pydantic schemas
用于数据验证和序列化
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime


class UserBase(BaseModel):
    """
    用户基础模型
    """
    username: str = Field(..., min_length=3, max_length=50, description="用户名")
    email: EmailStr = Field(..., description="邮箱地址")


class UserCreate(UserBase):
    """
    用户创建模型（注册）
    """
    password: str = Field(..., min_length=6, max_length=100, description="密码")

    @validator('password')
    def password_strength(cls, v):
        """
        验证密码强度
        """
        if not any(char.isdigit() for char in v):
            raise ValueError('密码必须包含至少一个数字')
        if not any(char.isalpha() for char in v):
            raise ValueError('密码必须包含至少一个字母')
        return v


class UserLogin(BaseModel):
    """
    用户登录模型
    """
    username: str = Field(..., description="用户名")
    password: str = Field(..., description="密码")


class UserUpdate(BaseModel):
    """
    用户更新模型
    """
    email: Optional[EmailStr] = None
    avatar: Optional[str] = None


class UserResponse(UserBase):
    """
    用户响应模型
    """
    id: int
    avatar: Optional[str] = None
    is_active: bool
    is_online: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UserSimple(BaseModel):
    """
    用户简单模型（用于列表显示）
    """
    id: int
    username: str
    avatar: Optional[str] = None
    is_online: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    """
    JWT Token响应模型
    """
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class TokenData(BaseModel):
    """
    Token数据模型
    """
    user_id: Optional[int] = None
    username: Optional[str] = None
