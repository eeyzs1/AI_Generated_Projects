"""
聊天室相关的Pydantic schemas
用于数据验证和序列化
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class RoomBase(BaseModel):
    """
    聊天室基础模型
    """
    name: str = Field(..., min_length=1, max_length=100, description="房间名称")
    description: Optional[str] = Field(None, max_length=500, description="房间描述")


class RoomCreate(RoomBase):
    """
    聊天室创建模型
    """
    is_private: bool = Field(False, description="是否私密")
    member_ids: Optional[List[int]] = Field(default=[], description="初始成员ID列表")


class RoomUpdate(BaseModel):
    """
    聊天室更新模型
    """
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    avatar: Optional[str] = None


class RoomResponse(RoomBase):
    """
    聊天室响应模型
    """
    id: int
    creator_id: int
    is_private: bool
    avatar: Optional[str] = None
    created_at: datetime
    member_count: int = 0

    class Config:
        from_attributes = True


class RoomDetail(RoomResponse):
    """
    聊天室详情模型
    """
    members: List["UserSimple"] = []

    class Config:
        from_attributes = True


class RoomMember(BaseModel):
    """
    聊天室成员操作模型
    """
    user_id: int = Field(..., description="用户ID")


# 避免循环导入
from schemas.user import UserSimple
RoomDetail.model_rebuild()
