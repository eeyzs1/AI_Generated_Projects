"""
WebSocket服务
处理实时消息传递和在线用户管理
"""
import json
from typing import Dict, Set, Optional
from fastapi import WebSocket
from datetime import datetime
from sqlalchemy.orm import Session

from models.user import User
from models.message import Message
from services.auth_service import AuthService


class ConnectionManager:
    """
    WebSocket连接管理器
    管理所有活跃的WebSocket连接
    """

    def __init__(self):
        # 用户ID到WebSocket连接的映射
        self.active_connections: Dict[int, WebSocket] = {}
        # 聊天室ID到用户ID集合的映射
        self.room_users: Dict[int, Set[int]] = {}
        # 在线用户集合
        self.online_users: Set[int] = set()

    async def connect(self, websocket: WebSocket, user_id: int):
        """
        建立WebSocket连接
        """
        await websocket.accept()
        self.active_connections[user_id] = websocket
        self.online_users.add(user_id)

    def disconnect(self, user_id: int):
        """
        断开WebSocket连接
        """
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        self.online_users.discard(user_id)

        # 从所有聊天室中移除用户
        for room_id in list(self.room_users.keys()):
            self.room_users[room_id].discard(user_id)

    async def send_personal_message(self, message: dict, user_id: int):
        """
        发送私人消息给特定用户
        """
        if user_id in self.active_connections:
            await self.active_connections[user_id].send_json(message)

    async def broadcast(self, message: dict):
        """
        广播消息给所有连接的用户
        """
        for connection in self.active_connections.values():
            await connection.send_json(message)

    async def broadcast_to_room(self, message: dict, room_id: int):
        """
        广播消息给聊天室内的所有用户
        """
        if room_id in self.room_users:
            for user_id in self.room_users[room_id]:
                await self.send_personal_message(message, user_id)

    def join_room(self, user_id: int, room_id: int):
        """
        用户加入聊天室
        """
        if room_id not in self.room_users:
            self.room_users[room_id] = set()
        self.room_users[room_id].add(user_id)

    def leave_room(self, user_id: int, room_id: int):
        """
        用户离开聊天室
        """
        if room_id in self.room_users:
            self.room_users[room_id].discard(user_id)

    def get_online_users(self) -> list:
        """
        获取在线用户列表
        """
        return list(self.online_users)

    def is_online(self, user_id: int) -> bool:
        """
        检查用户是否在线
        """
        return user_id in self.online_users

    def get_room_users(self, room_id: int) -> list:
        """
        获取聊天室内的用户列表
        """
        if room_id in self.room_users:
            return list(self.room_users[room_id])
        return []


# 创建全局连接管理器实例
manager = ConnectionManager()


class WebSocketService:
    """
    WebSocket服务类
    处理WebSocket消息的业务逻辑
    """

    @staticmethod
    async def handle_message(
        db: Session,
        user_id: int,
        data: dict
    ):
        """
        处理WebSocket消息
        """
        message_type = data.get("type")

        if message_type == "join":
            # 用户加入聊天室
            room_id = data.get("room_id")
            if room_id:
                manager.join_room(user_id, room_id)
                # 获取用户信息
                user = db.query(User).filter(User.id == user_id).first()
                await manager.broadcast_to_room({
                    "type": "system",
                    "content": f"{user.username} 加入了聊天室",
                    "room_id": room_id,
                    "timestamp": datetime.now().isoformat()
                }, room_id)

        elif message_type == "leave":
            # 用户离开聊天室
            room_id = data.get("room_id")
            if room_id:
                manager.leave_room(user_id, room_id)
                user = db.query(User).filter(User.id == user_id).first()
                await manager.broadcast_to_room({
                    "type": "system",
                    "content": f"{user.username} 离开了聊天室",
                    "room_id": room_id,
                    "timestamp": datetime.now().isoformat()
                }, room_id)

        elif message_type == "message":
            # 聊天消息
            room_id = data.get("room_id")
            content = data.get("content")
            if room_id and content:
                user = db.query(User).filter(User.id == user_id).first()
                # 广播消息给聊天室所有成员
                await manager.broadcast_to_room({
                    "type": "message",
                    "sender_id": user_id,
                    "sender_name": user.username if user else "Unknown",
                    "room_id": room_id,
                    "content": content,
                    "timestamp": datetime.now().isoformat()
                }, room_id)

        elif message_type == "typing":
            # 正在输入状态
            room_id = data.get("room_id")
            if room_id:
                user = db.query(User).filter(User.id == user_id).first()
                await manager.broadcast_to_room({
                    "type": "typing",
                    "sender_id": user_id,
                    "sender_name": user.username if user else "Unknown",
                    "room_id": room_id,
                    "timestamp": datetime.now().isoformat()
                }, room_id)

        elif message_type == "online_users":
            # 请求在线用户列表
            online_user_ids = manager.get_online_users()
            users = db.query(User).filter(User.id.in_(online_user_ids)).all()
            await manager.send_personal_message({
                "type": "online_users",
                "users": [{"id": u.id, "username": u.username, "avatar": u.avatar} for u in users]
            }, user_id)

    @staticmethod
    async def notify_user_status(user_id: int, is_online: bool, username: str):
        """
        通知用户状态变化
        """
        status_msg = "上线了" if is_online else "下线了"
        await manager.broadcast({
            "type": "user_status",
            "user_id": user_id,
            "username": username,
            "is_online": is_online,
            "content": f"{username} {status_msg}",
            "timestamp": datetime.now().isoformat()
        })
