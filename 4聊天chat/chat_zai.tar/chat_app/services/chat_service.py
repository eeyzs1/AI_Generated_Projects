"""
聊天服务
处理聊天室和消息相关的业务逻辑
"""
from typing import List, Optional
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from models.room import Room, room_members
from models.message import Message, MessageType
from models.user import User
from schemas.room import RoomCreate, RoomUpdate, RoomResponse, RoomDetail
from schemas.message import MessageCreate, MessageResponse


class ChatService:
    """
    聊天服务类
    """

    # ==================== 聊天室相关 ====================

    @staticmethod
    def create_room(db: Session, room_data: RoomCreate, creator_id: int) -> Room:
        """
        创建聊天室
        """
        # 创建聊天室
        new_room = Room(
            name=room_data.name,
            description=room_data.description,
            creator_id=creator_id,
            is_private=1 if room_data.is_private else 0
        )

        db.add(new_room)
        db.commit()
        db.refresh(new_room)

        # 将创建者添加到成员列表
        db.execute(
            room_members.insert().values(room_id=new_room.id, user_id=creator_id)
        )

        # 添加其他成员
        if room_data.member_ids:
            for member_id in room_data.member_ids:
                # 检查成员是否存在
                member = db.query(User).filter(User.id == member_id).first()
                if member and member_id != creator_id:
                    db.execute(
                        room_members.insert().values(room_id=new_room.id, user_id=member_id)
                    )

        db.commit()
        db.refresh(new_room)

        return new_room

    @staticmethod
    def get_room_by_id(db: Session, room_id: int) -> Optional[Room]:
        """
        根据ID获取聊天室
        """
        return db.query(Room).filter(Room.id == room_id).first()

    @staticmethod
    def get_rooms(db: Session, skip: int = 0, limit: int = 100) -> List[Room]:
        """
        获取聊天室列表
        """
        rooms = db.query(Room).offset(skip).limit(limit).all()
        return rooms

    @staticmethod
    def get_user_rooms(db: Session, user_id: int) -> List[Room]:
        """
        获取用户加入的聊天室列表
        """
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            return user.rooms
        return []

    @staticmethod
    def update_room(db: Session, room_id: int, room_data: RoomUpdate, user_id: int) -> Room:
        """
        更新聊天室信息
        """
        room = db.query(Room).filter(Room.id == room_id).first()
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="聊天室不存在"
            )

        # 检查是否是创建者
        if room.creator_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="只有创建者才能修改聊天室"
            )

        # 更新字段
        if room_data.name is not None:
            room.name = room_data.name
        if room_data.description is not None:
            room.description = room_data.description
        if room_data.avatar is not None:
            room.avatar = room_data.avatar

        db.commit()
        db.refresh(room)

        return room

    @staticmethod
    def delete_room(db: Session, room_id: int, user_id: int) -> bool:
        """
        删除聊天室
        """
        room = db.query(Room).filter(Room.id == room_id).first()
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="聊天室不存在"
            )

        # 检查是否是创建者
        if room.creator_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="只有创建者才能删除聊天室"
            )

        db.delete(room)
        db.commit()
        return True

    @staticmethod
    def add_member(db: Session, room_id: int, user_id: int, member_id: int) -> bool:
        """
        添加成员到聊天室
        """
        room = db.query(Room).filter(Room.id == room_id).first()
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="聊天室不存在"
            )

        # 检查用户是否已经是成员
        if member_id in [m.id for m in room.members]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="用户已经是聊天室成员"
            )

        # 检查要添加的成员是否存在
        member = db.query(User).filter(User.id == member_id).first()
        if not member:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )

        db.execute(
            room_members.insert().values(room_id=room_id, user_id=member_id)
        )
        db.commit()

        return True

    @staticmethod
    def remove_member(db: Session, room_id: int, user_id: int, member_id: int) -> bool:
        """
        从聊天室移除成员
        """
        room = db.query(Room).filter(Room.id == room_id).first()
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="聊天室不存在"
            )

        # 检查是否是创建者或自己退出
        if room.creator_id != user_id and user_id != member_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权移除该成员"
            )

        # 不能移除创建者
        if member_id == room.creator_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="不能移除聊天室创建者"
            )

        db.execute(
            room_members.delete().where(
                room_members.c.room_id == room_id,
                room_members.c.user_id == member_id
            )
        )
        db.commit()

        return True

    @staticmethod
    def is_room_member(db: Session, room_id: int, user_id: int) -> bool:
        """
        检查用户是否是聊天室成员
        """
        result = db.query(room_members).filter(
            room_members.c.room_id == room_id,
            room_members.c.user_id == user_id
        ).first()
        return result is not None

    # ==================== 消息相关 ====================

    @staticmethod
    def send_message(
        db: Session,
        message_data: MessageCreate,
        sender_id: int
    ) -> Message:
        """
        发送消息
        """
        # 检查用户是否是聊天室成员
        if not ChatService.is_room_member(db, message_data.room_id, sender_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="您不是该聊天室的成员"
            )

        # 创建消息
        new_message = Message(
            sender_id=sender_id,
            room_id=message_data.room_id,
            content=message_data.content,
            message_type=message_data.message_type
        )

        db.add(new_message)
        db.commit()
        db.refresh(new_message)

        return new_message

    @staticmethod
    def get_room_messages(
        db: Session,
        room_id: int,
        user_id: int,
        skip: int = 0,
        limit: int = 50
    ) -> List[Message]:
        """
        获取聊天室消息
        """
        # 检查用户是否是聊天室成员
        if not ChatService.is_room_member(db, room_id, user_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="您不是该聊天室的成员"
            )

        messages = db.query(Message).filter(
            Message.room_id == room_id
        ).order_by(desc(Message.created_at)).offset(skip).limit(limit).all()

        return messages

    @staticmethod
    def delete_message(db: Session, message_id: int, user_id: int) -> bool:
        """
        删除消息
        """
        message = db.query(Message).filter(Message.id == message_id).first()
        if not message:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="消息不存在"
            )

        # 只能删除自己发送的消息
        if message.sender_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="只能删除自己发送的消息"
            )

        db.delete(message)
        db.commit()

        return True
